package com.example.excluidosapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Tela6 extends AppCompatActivity {

    Button voltarbia, irbia;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela6);

        voltarbia = findViewById(R.id.btnvoltarbia);

        voltarbia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent voltbia = new Intent(getApplicationContext(), Tela5.class);
                startActivity(voltbia);

            }
        });

        irbia = findViewById(R.id.btnirbia);

        irbia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent irbia = new Intent(getApplicationContext(), Tela7.class);
                startActivity(irbia);

            }
        });

    }
}