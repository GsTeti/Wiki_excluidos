package com.example.excluidosapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class Tela3 extends AppCompatActivity {

    public Button voltarpers, irlaura;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela3);

        voltarpers = findViewById(R.id.btnvoltarlaura);

        voltarpers.setOnClickListener(view -> {

            Intent volthist = new Intent(getApplicationContext(), MainActivity.class);
            startActivity(volthist);

        });

        irlaura = findViewById(R.id.btnirlaura);

        irlaura.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent irlaura = new Intent(getApplicationContext(), Tela4.class);
                startActivity(irlaura);

            }
        });

    }}