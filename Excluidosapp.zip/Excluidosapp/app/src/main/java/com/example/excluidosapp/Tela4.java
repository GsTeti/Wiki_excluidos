package com.example.excluidosapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Tela4 extends AppCompatActivity {

    public Button voltarmarcos, irmarcos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela4);

        voltarmarcos = findViewById(R.id.btnvoltarmarcos);

        voltarmarcos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent voltmarc = new Intent(getApplicationContext(), Tela3.class);
                startActivity(voltmarc);

            }
        });

        irmarcos = findViewById(R.id.btnirmarcos);

        irmarcos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent irmarc = new Intent(getApplicationContext(), Tela5.class);
                startActivity(irmarc);

            }
        });

    }
}