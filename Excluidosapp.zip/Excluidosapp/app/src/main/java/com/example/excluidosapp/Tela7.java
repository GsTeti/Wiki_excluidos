package com.example.excluidosapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Tela7 extends AppCompatActivity {

    Button voltardora, irdora;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela7);

        voltardora = findViewById(R.id.btnvoltardora);

        voltardora.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent voltdo = new Intent(getApplicationContext(), Tela6.class);
                startActivity(voltdo);

            }
        });

        irdora = findViewById(R.id.btnirdora);

        irdora.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent irdo = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(irdo);

            }
        });

    }
}