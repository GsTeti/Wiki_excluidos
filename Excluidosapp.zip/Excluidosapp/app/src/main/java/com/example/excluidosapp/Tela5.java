package com.example.excluidosapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Tela5 extends AppCompatActivity {

    public Button voltaremilly, iremilly;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela5);

        voltaremilly = findViewById(R.id.btnvoltaremilly);

        voltaremilly.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent voltemi = new Intent(getApplicationContext(), Tela4.class);
                startActivity(voltemi);

            }
        });

        iremilly = findViewById(R.id.btniremilly);

        iremilly.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent iremi = new Intent(getApplicationContext(), Tela6.class);
                startActivity(iremi);

            }
        });

    }
}