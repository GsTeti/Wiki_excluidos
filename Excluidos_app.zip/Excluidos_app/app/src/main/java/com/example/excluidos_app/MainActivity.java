package com.example.excluidos_app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    Button botaoPers;
    private Button botaoWeb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        botaoPers= findViewById(R.id.btn_pers);

        botaoPers.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent pers = new Intent(getApplicationContext(), Tela2.class);
                startActivity(pers);

                botaoWeb = (Button) findViewById(R.id.btn_hist);

                botaoWeb.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://clube-dos-cinco-excluidos.fandom.com/pt-br/wiki/Clube_dos_cinco_exclu%C3%ADdos_Wiki")));

            }
        });


            }
        });

    }
}