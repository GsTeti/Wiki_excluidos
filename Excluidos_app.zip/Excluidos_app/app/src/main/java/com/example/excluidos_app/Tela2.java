package com.example.excluidos_app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Tela2 extends AppCompatActivity {

    private Button botaoWeb, botaoVoltar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela2);

        botaoVoltar = findViewById(R.id.btnvoltar);

        botaoVoltar.setOnClickListener(view -> {
            Intent voltar = new Intent(getApplicationContext(), MainActivity.class);
            startActivity(voltar);
        });

        botaoWeb = (Button) findViewById(R.id.btn_laura);

        botaoWeb.setOnClickListener((View view) -> {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://clube-dos-cinco-excluidos.fandom.com/pt-br/wiki/Laura")));
            /**/
            botaoWeb = (Button) findViewById(R.id.btn_marcos);

            botaoWeb.setOnClickListener((View view1) -> {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://clube-dos-cinco-excluidos.fandom.com/pt-br/wiki/Marcos")));
                /**/
                botaoWeb = (Button) findViewById(R.id.btn_emilly);

                botaoWeb.setOnClickListener((View view11) -> {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://clube-dos-cinco-excluidos.fandom.com/pt-br/wiki/Emilly")));
                    /**/
                    botaoWeb = (Button) findViewById(R.id.btn_bia);

                    botaoWeb.setOnClickListener((View view111) -> {
                        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://clube-dos-cinco-excluidos.fandom.com/pt-br/wiki/Beatriz")));
                        /**/
                        botaoWeb = (Button) findViewById(R.id.btn_dora);

                        botaoWeb.setOnClickListener((View view1111) -> {
                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://clube-dos-cinco-excluidos.fandom.com/pt-br/wiki/Dora")));
                        });
                    });
                });
            });
        });